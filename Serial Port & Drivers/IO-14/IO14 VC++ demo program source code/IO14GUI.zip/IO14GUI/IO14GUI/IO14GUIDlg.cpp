// IO14GUIDlg.cpp : implementation file
#include "stdafx.h"
#include "IO14GUI.h"
#include "IO14GUIDlg.h"
#include "afxdialogex.h"
#include "ftd2xx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif




//Globals
FT_HANDLE m_ftHandle;
FT_STATUS ft_status;
int tmode;
int ActiveChannel=0;
CEdit *pConfEdit;
float extref;
int numsamples;



// CAboutDlg dialog used for App About
class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CIO14GUIDlg dialog




CIO14GUIDlg::CIO14GUIDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CIO14GUIDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_DigInput = _T("-");
	m_C1 = 0;
	m_C2 = 0;
	m_ExtVref = _T("-");
	m_IntExtSelect = _T("-");
	m_Rate = _T("-");
	m_ReturnMode = _T("-");
	m_NumSamples = _T("-");
	m_CF = _T("-");
	m_ABMode = 1;
	m_SerNum = _T("");
	m_TempData = _T("");
	m_Channel = _T("0");
	m_A2DSingle = _T("");
	m_ActualCount = _T("");
	m_ExtVoltage = 0;
	m_SampleRate = 0;
	m_NumSamp = 0;
	m_CFMode = 0;
	m_ABMode2 = 0;
	m_Vref = 0;
}

void CIO14GUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	//  DDX_Text(pDX, IDC_EDIT_CHANNEL, m_Channel);
	DDX_Text(pDX, IDC_EDIT_DIG_INPUT, m_DigInput);
	DDX_Text(pDX, IDC_EDIT_CTR_C1, m_C1);
	DDX_Text(pDX, IDC_EDIT_CTR_C2, m_C2);
	DDX_Text(pDX, IDC_EDIT_EXTVREF, m_ExtVref);
	DDX_Text(pDX, IDC_EDIT_INTEXT_VREF, m_IntExtSelect);
	DDX_Text(pDX, IDC_EDIT_RATE, m_Rate);
	DDX_Text(pDX, IDC_EDIT_RETURN_MODE, m_ReturnMode);
	DDX_Text(pDX, IDC_EDITNUM_SAMPLES, m_NumSamples);
	DDX_Text(pDX, IDC_EDIT_CF, m_CF);
	DDX_Radio(pDX, IDC_RADIO_ABMode, m_ABMode);
	DDX_Text(pDX, IDC_EDIT_SERNUM, m_SerNum);
	DDX_Text(pDX, IDC_EDIT_TEMPDATA, m_TempData);
	DDX_Text(pDX, IDC_EDIT_CHANNEL, m_Channel);
	DDX_Text(pDX, IDC_EDIT_A2D_SINGLE, m_A2DSingle);
	DDX_Control(pDX, IDC_COMBO_A2DSAMPLES, m_A2DMultiple);
	DDX_Text(pDX, IDC_EDIT_DIG_ACTUALCOUNT, m_ActualCount);
	DDX_Radio(pDX, IDC_RADIO_EXT_VOLTAGE, m_ExtVoltage);
	DDX_Radio(pDX, IDC_RADIO_SAMP_RATE, m_SampleRate);
	DDX_Radio(pDX, IDC_RADIO_NUMSAMP, m_NumSamp);
	DDX_Radio(pDX, IDC_RADIO_CFMODE, m_CFMode);
	DDX_Radio(pDX, IDC_RADIO_ABMode, m_ABMode2);
	DDX_Radio(pDX, IDC_RADIO_VREF, m_Vref);
}

BEGIN_MESSAGE_MAP(CIO14GUIDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CIO14GUIDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON_RELSET, &CIO14GUIDlg::OnBnClickedButtonRelset)
	ON_BN_CLICKED(IDC_BUTTON_RLYRSET, &CIO14GUIDlg::OnBnClickedButtonRlyrset)
	ON_BN_CLICKED(IDC_BUTTON_LEDON, &CIO14GUIDlg::OnBnClickedButtonLedon)
	ON_BN_CLICKED(IDC_BUTTON_LEDOFF, &CIO14GUIDlg::OnBnClickedButtonLedoff)
	ON_BN_CLICKED(IDC_BUTTON_LEDFLASH, &CIO14GUIDlg::OnBnClickedButtonLedflash)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN2, &CIO14GUIDlg::OnDeltaposSpin2)
	ON_BN_CLICKED(IDC_BUTTON_DIG_HIGH, &CIO14GUIDlg::OnBnClickedButtonDigHigh)
	ON_BN_CLICKED(IDC_BUTTON_DIG_LOW, &CIO14GUIDlg::OnBnClickedButtonDigLow)
	ON_BN_CLICKED(IDC_BUTTON_DIG_READ, &CIO14GUIDlg::OnBnClickedButtonDigRead)
	ON_BN_CLICKED(IDC_BUTTON_READC1, &CIO14GUIDlg::OnBnClickedButtonReadc1)
	ON_BN_CLICKED(IDC_BUTTON_READC2, &CIO14GUIDlg::OnBnClickedButtonReadc2)
	ON_BN_CLICKED(IDC_BUTTON_CTR_CLEARC1, &CIO14GUIDlg::OnBnClickedButtonCtrClearc1)
	ON_BN_CLICKED(IDC_BUTTON_CTR_CLEARC2, &CIO14GUIDlg::OnBnClickedButtonCtrClearc2)
	ON_BN_CLICKED(IDC_BUTTON_SINGCH, &CIO14GUIDlg::OnBnClickedButtonSingch)
	ON_BN_CLICKED(IDC_BUTTON_READ_SETUP, &CIO14GUIDlg::OnBnClickedButtonReadSetup)
	ON_BN_CLICKED(IDC_RADIO_EXT_VOLTAGE, &CIO14GUIDlg::OnClickedRadioExtVoltage)
	ON_BN_CLICKED(IDC_RADIO2, &CIO14GUIDlg::OnBnClickedRadio2)
	ON_BN_CLICKED(IDC_RADIO3, &CIO14GUIDlg::OnBnClickedRadio3)
	ON_BN_CLICKED(IDC_RADIO4, &CIO14GUIDlg::OnBnClickedRadio4)
	ON_BN_CLICKED(IDC_RADIO5, &CIO14GUIDlg::OnBnClickedRadio5)
	ON_BN_CLICKED(IDC_RADIO6, &CIO14GUIDlg::OnBnClickedRadio6)
	ON_BN_CLICKED(IDC_RADIO7, &CIO14GUIDlg::OnBnClickedRadio7)
	ON_BN_CLICKED(IDC_RADIO8, &CIO14GUIDlg::OnBnClickedRadio8)
	ON_BN_CLICKED(IDC_RADIO9, &CIO14GUIDlg::OnBnClickedRadio9)
	ON_BN_CLICKED(IDC_RADIO10, &CIO14GUIDlg::OnBnClickedRadio10)
//	ON_BN_CLICKED(IDC_RADIO_EXT_VOLTAGE2, &CIO14GUIDlg::OnBnClickedRadioExtVoltage2)
	ON_BN_CLICKED(IDC_RADIO11, &CIO14GUIDlg::OnBnClickedRadio11)
	ON_BN_CLICKED(IDC_RADIO12, &CIO14GUIDlg::OnBnClickedRadio12)
	ON_BN_CLICKED(IDC_RADIO13, &CIO14GUIDlg::OnBnClickedRadio13)
	ON_BN_CLICKED(IDC_RADIO14, &CIO14GUIDlg::OnBnClickedRadio14)
	ON_BN_CLICKED(IDC_RADIO15, &CIO14GUIDlg::OnBnClickedRadio15)
	ON_BN_CLICKED(IDC_RADIO16, &CIO14GUIDlg::OnBnClickedRadio16)
	ON_BN_CLICKED(IDC_RADIO17, &CIO14GUIDlg::OnBnClickedRadio17)
//	ON_BN_CLICKED(IDC_RADIO18, &CIO14GUIDlg::OnBnClickedRadio18)
	ON_BN_CLICKED(IDC_RADIO19, &CIO14GUIDlg::OnBnClickedRadio19)
	ON_BN_CLICKED(IDC_RADIO20, &CIO14GUIDlg::OnBnClickedRadio20)
	ON_BN_CLICKED(IDC_RADIO21, &CIO14GUIDlg::OnBnClickedRadio21)
	ON_BN_CLICKED(IDC_RADIO22, &CIO14GUIDlg::OnBnClickedRadio22)
	ON_BN_CLICKED(IDC_RADIO23, &CIO14GUIDlg::OnBnClickedRadio23)
	ON_BN_CLICKED(IDC_RADIO24, &CIO14GUIDlg::OnBnClickedRadio24)
	ON_BN_CLICKED(IDC_RADIO25, &CIO14GUIDlg::OnBnClickedRadio25)
	ON_BN_CLICKED(IDC_RADIO26, &CIO14GUIDlg::OnBnClickedRadio26)
	ON_BN_CLICKED(IDC_RADIO27, &CIO14GUIDlg::OnBnClickedRadio27)
	ON_BN_CLICKED(IDC_RADIO28, &CIO14GUIDlg::OnBnClickedRadio28)
	ON_BN_CLICKED(IDC_RADIO29, &CIO14GUIDlg::OnBnClickedRadio29)
	ON_BN_CLICKED(IDC_RADIO_VREF, &CIO14GUIDlg::OnBnClickedRadioVref)
	ON_BN_CLICKED(IDC_RADIO30, &CIO14GUIDlg::OnBnClickedRadio30)
	ON_BN_CLICKED(IDC_RADIO_CFMODE, &CIO14GUIDlg::OnBnClickedRadioCfmode)
	ON_BN_CLICKED(IDC_RADIO_ABMode, &CIO14GUIDlg::OnBnClickedRadioAbmode)
	ON_BN_CLICKED(IDC_BUTTON_Detect, &CIO14GUIDlg::OnBnClickedButtonDetect)
	ON_BN_CLICKED(IDC_BUTTON_READTEMP, &CIO14GUIDlg::OnBnClickedButtonReadtemp)
	ON_BN_CLICKED(IDC_RADIO12BIT, &CIO14GUIDlg::OnBnClickedRadio12bit)
	ON_BN_CLICKED(IDC_RADIO11BIT, &CIO14GUIDlg::OnBnClickedRadio11bit)
	ON_BN_CLICKED(IDC_RADIO_10BIT, &CIO14GUIDlg::OnBnClickedRadio10bit)
	ON_BN_CLICKED(IDC_RADIO_9BIT, &CIO14GUIDlg::OnBnClickedRadio9bit)
	ON_BN_CLICKED(IDC_BUTTON1, &CIO14GUIDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_RADIO_SAMP_RATE, &CIO14GUIDlg::OnBnClickedRadioSampRate)
	ON_BN_CLICKED(IDC_RADIO_NUMSAMP, &CIO14GUIDlg::OnBnClickedRadioNumsamp)
END_MESSAGE_MAP()
// CIO14GUIDlg message handlers




void CIO14GUIDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CIO14GUIDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CIO14GUIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



//*********************************************************************************************************
void CIO14GUIDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();
}


//*********************************************************************************************************
BOOL CIO14GUIDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	//open the port and send command byte for binary operation
	unsigned char tx[10]; 
	DWORD ret_bytes;
	if(OpenPort()==0)
	{
		Purge();
		tx[0] = 0x68; //set binary mode
		ft_status = FT_Write(m_ftHandle, tx, 1, &ret_bytes);
		if(ft_status>0) 
		{
			AfxMessageBox(_T("Error writing to DLP module. Make sure VCP drivers are disabled."));
			FT_Close(m_ftHandle);
			exit(0);
		}
	}
	else
	{
		AfxMessageBox(_T("Error opening DLP module. Make sure VCP drivers are disabled."));
		FT_Close(m_ftHandle);
		exit(0);
	}

	OnBnClickedButtonReadSetup(); //load default setup values to GUI

	pConfEdit = (CEdit *)GetDlgItem(IDC_COMBO_A2DSAMPLES);
	pConfEdit->ShowWindow(FALSE);
	pConfEdit = (CEdit *)GetDlgItem(IDC_EDIT_A2D_SINGLE);
	pConfEdit->ShowWindow(TRUE);


	FT_Close(m_ftHandle);
	return TRUE;  // return TRUE  unless you set the focus to a control
}







//*************************************************************************
int CIO14GUIDlg::OpenPort(void)
{
	int x=0;
	CString str;
	unsigned char tx[10], rx[6000];
	DWORD AmountInRxQueue;
	DWORD ret_bytes;
	int pos;

	ft_status = FT_OpenEx((PVOID)(LPCTSTR)"DLP-IO14", FT_OPEN_BY_DESCRIPTION, &m_ftHandle);
	if(ft_status)
	{		
		//AfxMessageBox("Error: Could not open a device (410)");
		return 1;
	}

	FT_SetTimeouts(m_ftHandle, 500, 500);

//	Sleep(50);
	Purge();

	//ping IO14 
	pos=0;
	tx[pos++] = 0x27;
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		//AfxMessageBox("Error writing to DLP module. (514)");
		FT_Close(m_ftHandle);
		return 2;
	}

	int reply=100;//1000mS timeout
	while(reply>0)
	{
		reply--;
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue > 0)
			reply=0;
		
		if(reply==1)//timeout
			return 3;
	}

	ft_status = FT_Read(m_ftHandle, rx, 1, &ret_bytes);
	if(ft_status != FT_OK)
	{
		//AfxMessageBox("Read Error! (440)");
		FT_Close(m_ftHandle);
		return 4;
	}


	if(rx[0] != 'N')
	{
		//AfxMessageBox("Error: Wrong data returned (460)");
		FT_Close(m_ftHandle);
		return 6;
	}

	return 0;
}




//****************************************************************************
void CIO14GUIDlg::Purge()
{
	DWORD AmountInRxQueue, BytesReturned;
	unsigned char rx[1001];

	Sleep(5);
	FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	if(AmountInRxQueue > 1000) AmountInRxQueue = 1000;
	while(AmountInRxQueue)
	{
		FT_Read(m_ftHandle, rx, AmountInRxQueue, &BytesReturned);//read the data from the buffer
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue > 1000) AmountInRxQueue = 1000;
		Sleep(5);
	}
}

//**********************************************************************************
void CIO14GUIDlg::OnBnClickedButtonRelset()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x6B; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}


//******************************************************************************************************
void CIO14GUIDlg::OnBnClickedButtonRlyrset()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x6D; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}


//******************************************************************************************************
void CIO14GUIDlg::OnBnClickedButtonLedon()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2E; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
	
}


//******************************************************************************************************
void CIO14GUIDlg::OnBnClickedButtonLedoff()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x60; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}


//******************************************************************************************************
void CIO14GUIDlg::OnBnClickedButtonLedflash()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2B; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}

//******************************************************************************
void CIO14GUIDlg::OnDeltaposSpin2(NMHDR *pNMHDR, LRESULT *pResult)
{
	int ret;
	unsigned char tx[40];
	DWORD ret_bytes;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	
	ActiveChannel -= pNMUpDown->iDelta; //proposed change in position
	if(	ActiveChannel < 1)
		ActiveChannel = 1;
    if(ActiveChannel > 14)
		ActiveChannel = 14;



	UpdateData(TRUE); //read current data from the window
	m_Channel.Format(_T("%d"), ActiveChannel);
	if(ActiveChannel == 13) // if channels A1
		m_Channel.Format(_T("A1"), ActiveChannel);
	if(ActiveChannel == 14) // if channels A2
		m_Channel.Format(_T("A2"), ActiveChannel);
	UpdateData(FALSE);
	UpdateWindow();
		


	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	tx[0] = 0x30 + ActiveChannel; 
	if(ActiveChannel > 9) // channels 10,11,12,A1,A2
		tx[0] = 87 + ActiveChannel; // 0x57 + 10,11,12,13,14
	ft_status = FT_Write(m_ftHandle, tx, 1, &ret_bytes);
	if(ft_status != FT_OK) 
		AfxMessageBox(_T("Error writing to DLP module. (504)"));

	FT_Close(m_ftHandle);

	*pResult = 0;
}

//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonDigHigh()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x77; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonDigLow()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x73; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonDigRead()
{
	int ret, pos;
	unsigned char tx[40], rx[40];
	DWORD ret_bytes, AmountInRxQueue;

	UpdateData(TRUE);
	m_DigInput.Format(_T("-"));
	UpdateData(FALSE);


	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x72; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	int reply=100;//1000mS timeout
	while(reply>0)
	{
		reply--;
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue == 1)
			reply=0;
		
		if(reply==1)//timeout
			return;
	}

	ft_status = FT_Read(m_ftHandle, rx, 1, &ret_bytes);
	if(ft_status != FT_OK)
	{
		//AfxMessageBox("Read Error! (440)");
		FT_Close(m_ftHandle);
		return;
	}

	UpdateData(TRUE);
	if(rx[0]==0)
		m_DigInput.Format(_T("0"));
	if(rx[0]==1)
		m_DigInput.Format(_T("1"));
	UpdateData(FALSE);
	UpdateWindow();
	
	FT_Close(m_ftHandle);
}





//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonReadc1()
{
	int ret, pos, temp;
	unsigned char tx[40], rx[40];
	DWORD ret_bytes, AmountInRxQueue;

	UpdateData(TRUE);
	m_DigInput.Format(_T("-"));
	UpdateData(FALSE);


	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x6E; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	int reply=100;//1000mS timeout
	while(reply>0)
	{
		reply--;
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue == 4)
			reply=0;
		
		if(reply==1)//timeout
			return;
	}

	ft_status = FT_Read(m_ftHandle, rx, 4, &ret_bytes);
	if(ft_status != FT_OK)
	{
		//AfxMessageBox("Read Error! (440)");
		FT_Close(m_ftHandle);
		return;
	}

	temp = rx[0]<<24 | rx[1]<<16 | rx[2]<<8 | rx[3];

	UpdateData(TRUE);
	m_C1 = temp;
	UpdateData(FALSE);
	UpdateWindow();
	
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonReadc2()
{
	int ret, pos, temp;
	unsigned char tx[40], rx[40];
	DWORD ret_bytes, AmountInRxQueue;

	UpdateData(TRUE);
	m_DigInput.Format(_T("-"));
	UpdateData(FALSE);


	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x70; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	int reply=100;//1000mS timeout
	while(reply>0)
	{
		reply--;
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue == 4)
			reply=0;
		
		if(reply==1)//timeout
			return;
	}

	ft_status = FT_Read(m_ftHandle, rx, 4, &ret_bytes);
	if(ft_status != FT_OK)
	{
		//AfxMessageBox("Read Error! (440)");
		FT_Close(m_ftHandle);
		return;
	}

	temp = rx[0]<<24 | rx[1]<<16 | rx[2]<<8 | rx[3];

	UpdateData(TRUE);
	m_C2 = temp;
	UpdateData(FALSE);
	UpdateWindow();
	
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonCtrClearc1()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x75; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonCtrClearc2()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x79; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}





//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonReadSetup()
{
	int ret, pos;
	unsigned char tx[40], rx[40];
	DWORD ret_bytes, AmountInRxQueue;

	UpdateData(TRUE);
	//m_DigInput.Format(_T("-"));
	UpdateData(FALSE);


	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x6A; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	int reply=100;//1000mS timeout
	while(reply>0)
	{
		reply--;
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue == 6)
			reply=0;
		
		if(reply==1)//timeout
			return;
	}

	ft_status = FT_Read(m_ftHandle, rx, 6, &ret_bytes);
	if(ft_status != FT_OK)
	{
		//AfxMessageBox("Read Error! (440)");
		FT_Close(m_ftHandle);
		return;
	}


	UpdateData(TRUE);
	if(rx[0] == 0){	m_ExtVref = _T("0: 2.2V"); extref = (float)2.2; }
	if(rx[0] == 1){ m_ExtVref = _T("1: 2.5V"); extref = (float)2.5; }
	if(rx[0] == 2){	m_ExtVref = _T("2: 3.0V"); extref = (float)3.0; }
	if(rx[0] == 3){	m_ExtVref = _T("3: 3.3V"); extref = (float)3.3; }
	if(rx[0] == 4){	m_ExtVref = _T("4: 3.5V"); extref = (float)3.5; }
	if(rx[0] == 5){	m_ExtVref = _T("5: 4.0V"); extref = (float)4.0; }
	if(rx[0] == 6){	m_ExtVref = _T("6: 4.096V"); extref = (float)4.096; }
	if(rx[0] == 7){	m_ExtVref = _T("7: 4.5V"); extref = (float)4.5; }
	if(rx[0] == 8){	m_ExtVref = _T("8: 4.8V"); extref = (float)4.8; }
	if(rx[0] == 9){	m_ExtVref = _T("9: 5.0V"); extref = (float)5.0; }
	m_ExtVoltage = rx[0];

	if(rx[1] == 0) m_Rate = _T("0: 200s/s");
	if(rx[1] == 1) m_Rate = _T("1: 500s/s");
	if(rx[1] == 2) m_Rate = _T("2: 1Ks/s");
	if(rx[1] == 3) m_Rate = _T("3: 2Ks/s");
	if(rx[1] == 4) m_Rate = _T("4: 4Ks/s");
	if(rx[1] == 5) m_Rate = _T("5: 10Ks/s");
	if(rx[1] == 6) m_Rate = _T("6: 20Ks/s");
	if(rx[1] == 7) m_Rate = _T("7: 30Ks/s");
	if(rx[1] == 8) m_Rate = _T("8: 40Ks/s");
	if(rx[1] == 9) m_Rate = _T("9: 50Ks/s");
	m_SampleRate = rx[1];

	if(rx[2] == 0){ m_NumSamples = _T("0: 32"); numsamples=32; }
	if(rx[2] == 1){ m_NumSamples = _T("1: 64"); numsamples=64; }
	if(rx[2] == 2){ m_NumSamples = _T("2: 128"); numsamples=128; }
	if(rx[2] == 3){ m_NumSamples = _T("3: 256"); numsamples=256; }
	if(rx[2] == 4){ m_NumSamples = _T("4: 512"); numsamples=512; }
	if(rx[2] == 5){ m_NumSamples = _T("5: 1024"); numsamples=1024; }
	if(rx[2] == 6){ m_NumSamples = _T("6: 2048"); numsamples=2048; }
	if(rx[2] == 7){ m_NumSamples = _T("7: 4096"); numsamples=4096; }
	if(rx[2] == 8){ m_NumSamples = _T("8: 8192"); numsamples=8192; }
	m_NumSamp = rx[2];


	if(rx[3] == 0) 
	{
		m_CF = _T("0: �F");
		tmode=0;//F
	}
	else
	{
		m_CF = _T("1: �C");
		tmode=1;//C
	}
	m_CFMode = rx[3];
	
	if(rx[4] == 0) 
		m_ReturnMode = _T("0: ASCII");
	else
		m_ReturnMode = _T("1: Binary");
	m_ABMode2 = rx[4];


	if(rx[5] == 0) 
	{
		m_IntExtSelect = _T("0: Int");
		extref=5.0;
	}
	else
	{
		m_IntExtSelect = _T("1: Ext");
		//extref set above
	}
	m_Vref = rx[5];


	UpdateData(FALSE);
	UpdateWindow();
	
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnClickedRadioExtVoltage()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x0; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio2()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x1; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio3()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x2; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio4()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x3; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio5()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x4; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio6()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x5; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio7()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x6; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio8()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x7; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio9()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x8; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio10()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2A; 
	tx[pos++] = 0x9; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadioExtVoltage2()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x0; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//****************************************************************************************
void CIO14GUIDlg::OnBnClickedRadioSampRate()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x0; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);

}

//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio11()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x1; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio12()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x2; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio13()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x3; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio14()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x4; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio15()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x5; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio16()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x6; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio17()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x7; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio18()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x8; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio19()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x3D; 
	tx[pos++] = 0x9; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}




//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadioNumsamp()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5B; 
	tx[pos++] = 0x0; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}





//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio20()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5B; 
	tx[pos++] = 0x1; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio21()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5B; 
	tx[pos++] = 0x2; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio22()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5B; 
	tx[pos++] = 0x3; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio23()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5B; 
	tx[pos++] = 0x4; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio24()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5B; 
	tx[pos++] = 0x5; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio25()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5B; 
	tx[pos++] = 0x6; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio26()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5B; 
	tx[pos++] = 0x7; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio27()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5B; 
	tx[pos++] = 0x8; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}







//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio29()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x69; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadioVref()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x69; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
    
	OnBnClickedRadio10();//select 5.0V reference
	
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio30()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x78; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadioCfmode()//Set Degrees F
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x66; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio28()//Set degrees C
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x67; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	Sleep(10);//give IO14 time to store setup change
	OnBnClickedButtonReadSetup();
	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadioAbmode()
{
	AfxMessageBox(_T("This program only works in Binary mode."));

	UpdateData(TRUE);
	m_ABMode = 1;
	UpdateData(FALSE);
	UpdateWindow();
}



//*******************************************************************
void CIO14GUIDlg::OnBnClickedButtonDetect()
{
	int ret, pos;
	unsigned char tx[40], rx[40];
	DWORD ret_bytes, AmountInRxQueue;

	UpdateData(TRUE);
	m_SerNum.Format(_T("-"));
	UpdateData(FALSE);
	UpdateWindow();

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5D; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	int reply=100;//1000mS timeout
	while(reply>0)
	{
		reply--;
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue == 8)
			reply=0;
		
		if(reply==1)//timeout
			return;
	}

	ft_status = FT_Read(m_ftHandle, rx, 8, &ret_bytes);
	if(ft_status != FT_OK)
	{
		//AfxMessageBox("Read Error! (440)");
		FT_Close(m_ftHandle);
		return;
	}

	UpdateData(TRUE);
	m_SerNum.Format(_T("%X%X%X%X%X%X%X%X"), rx[7], rx[6], rx[5], rx[4], rx[3], rx[2], rx[1], rx[0]);
	UpdateData(FALSE);
	UpdateWindow();

}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonReadtemp()
{
	int ret, pos;
	unsigned char tx[40], rx[40];
	DWORD ret_bytes, AmountInRxQueue;

	UpdateData(TRUE);
	m_TempData.Format(_T("-"));
	UpdateData(FALSE);
	UpdateWindow();

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x74; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	int reply=100;//1000mS timeout
	while(reply>0)
	{
		reply--;
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue == 2)
			reply=0;
		
		if(reply==1)//timeout
			return;
	}

	ft_status = FT_Read(m_ftHandle, rx, 2, &ret_bytes);
	if(ft_status != FT_OK)
	{
		//AfxMessageBox("Read Error! (440)");
		FT_Close(m_ftHandle);
		return;
	}


	//calculate DegC
	int isnegative=0;
	int temp = rx[0] | (rx[1] << 8);
	if( (temp & 0x8000) == 0x8000 )//if MSBit is set then negative temperature
	{
		temp &= 0x07ff;
		isnegative=1;
		temp = 0x800 - temp;
	}
		
	temp &= 0x07ff;	
	float degc1 = (float)((float)temp/16.0);
	if(isnegative) degc1 *= -1;

	UpdateData(TRUE);
	if(tmode==1)//C
		m_TempData.Format(_T("%03.2f�C"), degc1);

	if(tmode==0)//F
	{
		//convert to F
		m_TempData.Format(_T("%03.2f�F"), degc1*9.0/5.0+32.0);
	}

	UpdateData(FALSE);
	UpdateWindow();
}





//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio12bit()
{
		int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x5C; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio11bit()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x30; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio10bit()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2C; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}


//******************************************************************************
void CIO14GUIDlg::OnBnClickedRadio9bit()
{
	int ret, pos;
	unsigned char tx[40];
	DWORD ret_bytes;

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x2D; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	FT_Close(m_ftHandle);
}



//******************************************************************************
void CIO14GUIDlg::OnBnClickedButtonSingch()
{
	int ret, pos, temp;
	unsigned char tx[40], rx[40];
	DWORD ret_bytes, AmountInRxQueue;
	float vdata;

	pConfEdit = (CEdit *)GetDlgItem(IDC_EDIT_DIG_ACTUALCOUNT);
	pConfEdit->ShowWindow(FALSE);
	pConfEdit = (CEdit *)GetDlgItem(IDC_COMBO_A2DSAMPLES);
	pConfEdit->ShowWindow(FALSE);
	pConfEdit = (CEdit *)GetDlgItem(IDC_EDIT_A2D_SINGLE);
	pConfEdit->ShowWindow(TRUE);	
	UpdateWindow();
	
	UpdateData(TRUE);
	m_A2DSingle.Format(_T("-"));
	UpdateData(FALSE);
	UpdateWindow();

	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x76; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	int reply=100;//1000mS timeout
	while(reply>0)
	{
		reply--;
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue == 2)
			reply=0;
		
		if(reply==1)//timeout
			return;
	}

	ft_status = FT_Read(m_ftHandle, rx, 2, &ret_bytes);
	if(ft_status != FT_OK)
	{
		FT_Close(m_ftHandle);
		return;
	}

	temp = rx[0] + (rx[1]<<8);

	vdata = (float)temp / (float)1023.0 * (float)extref;

	if(ActiveChannel > 12)
		vdata = ( (float)vdata - ((float)extref/(float)2.0) ) * (float)2.0;

	UpdateData(TRUE);
	m_A2DSingle.Format(_T("%02.3fV"), vdata);
	UpdateData(FALSE);
	UpdateWindow();
}


//*******************************************************************************
void CIO14GUIDlg::OnBnClickedButton1()//multiple samples
{
	int ret, pos, temp, x;
	int actualcount;
	unsigned char tx[40], rx[40];
	DWORD ret_bytes, AmountInRxQueue;
	float vdata;
	CString str;

	pConfEdit = (CEdit *)GetDlgItem(IDC_EDIT_DIG_ACTUALCOUNT);
	pConfEdit->ShowWindow(TRUE);
	pConfEdit = (CEdit *)GetDlgItem(IDC_COMBO_A2DSAMPLES);
	pConfEdit->ShowWindow(TRUE);
	pConfEdit = (CEdit *)GetDlgItem(IDC_EDIT_A2D_SINGLE);
	pConfEdit->ShowWindow(FALSE);
	UpdateWindow();

	m_A2DMultiple.ResetContent();
	UpdateData(TRUE);
	m_ActualCount.Format(_T("-"));
	UpdateData(FALSE);
	UpdateWindow();


	FT_Close(m_ftHandle);
	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox(_T("Error: Could not open the port."));
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x7A; 
	ft_status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);
	if(ft_status != FT_OK) 
	{
		AfxMessageBox(_T("Error writing to DLP module. (504)"));
	}

	//wait for data to start to arrive
	FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	while(AmountInRxQueue<2)
	{
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	}

	actualcount=0;
	for(x=0; x<numsamples; x++)
	{
		actualcount++;

		int reply=200000;//short timeout
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		while(reply>0)
		{
			reply--;
			FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
			if(AmountInRxQueue > 1)
				reply=0;
		
			if(reply==1)//timeout
				return;
		}

		ft_status = FT_Read(m_ftHandle, rx, 2, &ret_bytes);
		if(ft_status != FT_OK)
		{
			FT_Close(m_ftHandle);
			return;
		}

		temp = rx[0] + (rx[1]<<8);

		vdata = (float)temp / (float)1023.0 * (float)extref;
		if(ActiveChannel > 12)
			vdata = ( (float)vdata - ((float)extref/(float)2.0) ) * (float)2.0;

		str.Format(_T("%02.3fV"), vdata);
		m_A2DMultiple.AddString(str);
	}

	UpdateData(TRUE);
	m_ActualCount.Format(_T("Cnt:%d"), actualcount);
	UpdateData(FALSE);
	UpdateWindow();

	m_A2DMultiple.SetCurSel(0);
}



