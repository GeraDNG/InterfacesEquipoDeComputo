// IO14GUIDlg.h : header file
#include "ftd2xx.h"

#pragma once

// CIO14GUIDlg dialog
class CIO14GUIDlg : public CDialogEx
{
// Construction
public:
	CIO14GUIDlg(CWnd* pParent = NULL);	// standard constructor
	int CIO14GUIDlg::OpenPort(void);
	void CIO14GUIDlg::Purge();





// Dialog Data
	enum { IDD = IDD_IO14GUI_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButtonRelset();
	afx_msg void OnBnClickedButtonRlyrset();
	afx_msg void OnBnClickedButtonLedon();
	afx_msg void OnBnClickedButtonLedoff();
	afx_msg void OnBnClickedButtonLedflash();
	afx_msg void OnDeltaposSpin2(NMHDR *pNMHDR, LRESULT *pResult);
//	int m_Channel;
	afx_msg void OnBnClickedButtonDigHigh();
	afx_msg void OnBnClickedButtonDigLow();
	afx_msg void OnBnClickedButtonDigRead();
	CString m_DigInput;
	afx_msg void OnBnClickedButtonReadc1();
	afx_msg void OnBnClickedButtonReadc2();
	UINT m_C1;
	UINT m_C2;
	afx_msg void OnBnClickedButtonCtrClearc1();
	afx_msg void OnBnClickedButtonCtrClearc2();
	afx_msg void OnBnClickedButtonSingch();
	afx_msg void OnBnClickedButtonReadSetup();
	CString m_ExtVref;
	CString m_IntExtSelect;
	CString m_Rate;
	CString m_ReturnMode;
	CString m_NumSamples;
	CString m_CF;
	afx_msg void OnClickedRadioExtVoltage();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedRadio3();
	afx_msg void OnBnClickedRadio4();
	afx_msg void OnBnClickedRadio5();
	afx_msg void OnBnClickedRadio6();
	afx_msg void OnBnClickedRadio7();
	afx_msg void OnBnClickedRadio8();
	afx_msg void OnBnClickedRadio9();
	afx_msg void OnBnClickedRadio10();
	afx_msg void OnBnClickedRadioExtVoltage2();
	afx_msg void OnBnClickedRadio11();
	afx_msg void OnBnClickedRadio12();
	afx_msg void OnBnClickedRadio13();
	afx_msg void OnBnClickedRadio14();
	afx_msg void OnBnClickedRadio15();
	afx_msg void OnBnClickedRadio16();
	afx_msg void OnBnClickedRadio17();
	afx_msg void OnBnClickedRadio18();
	afx_msg void OnBnClickedRadio19();
	afx_msg void OnBnClickedRadioExtVoltage3();
	afx_msg void OnBnClickedRadio20();
	afx_msg void OnBnClickedRadio21();
	afx_msg void OnBnClickedRadio22();
	afx_msg void OnBnClickedRadio23();
	afx_msg void OnBnClickedRadio24();
	afx_msg void OnBnClickedRadio25();
	afx_msg void OnBnClickedRadio26();
	afx_msg void OnBnClickedRadio27();
	afx_msg void OnBnClickedRadioExtVoltage4();
	afx_msg void OnBnClickedRadio28();
	afx_msg void OnBnClickedRadioExtVoltage5();
	afx_msg void OnBnClickedRadio29();
	BOOL m_ABMode;
	afx_msg void OnBnClickedRadioVref();
	afx_msg void OnBnClickedRadio30();
	afx_msg void OnBnClickedRadioCfmode();
	afx_msg void OnBnClickedRadioAbmode();
	afx_msg void OnBnClickedButtonDetect();
	CString m_SerNum;
	CString m_TempData;
	afx_msg void OnBnClickedButtonReadtemp();
	afx_msg void OnBnClickedRadio12bit();
	afx_msg void OnBnClickedRadio11bit();
	afx_msg void OnBnClickedRadio10bit();
	afx_msg void OnBnClickedRadio9bit();
	CString m_Channel;
	CString m_A2DSingle;
	CComboBox m_A2DMultiple;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedRadioSampRate();
	afx_msg void OnBnClickedRadioNumsamp();
	CString m_ActualCount;
	int m_ExtVoltage;
	int m_SampleRate;
	int m_NumSamp;
	int m_CFMode;
	int m_ABMode2;
	int m_Vref;
};
