//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IO20.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_IO20_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_STATUS                 1000
#define IDC_BUTTON_LED_ON               1001
#define IDC_BUTTON_LED_OFF              1002
#define IDC_BUTTON_FLASH_LEDS           1003
#define IDC_BUTTON_R1_SET               1004
#define IDC_BUTTON_R1_RESET             1005
#define IDC_BUTTON_R2_SET               1006
#define IDC_BUTTON_R2_RESET             1007
#define IDC_COMBO1_DEVS                 1008
#define IDC_BUTTON_CONNECT              1009
#define IDC_EDIT_STREAM_VOLTAGE         1016
#define IDC_RADIO_REF_SELECT            1017
#define IDC_RADIO3                      1018
#define IDC_EDIT_REF_VOLTAGE            1019
#define IDC_EDIT_PACKET_WINDOW          1040
#define IDC_SPIN2                       1043
#define IDC_EDIT_DIGI_CHANNEL           1044
#define IDC_BUTTON_DIG_HIGH             1045
#define IDC_BUTTON_DIG_LOW              1046
#define IDC_BUTTON_DIG_READ             1047
#define IDC_EDIT_DIG_INPUT              1048
#define IDC_SPIN3                       1049
#define IDC_EDIT_DIGI_CHANNEL2          1050
#define IDC_RADIO_CTR_TRIGGER           1051
#define IDC_RADIO2                      1052
#define IDC_BUTTON_CTR_CLEAR            1053
#define IDC_BUTTON_CTR_READ             1054
#define IDC_EDIT_CTR_DECIMAL            1055
#define IDC_EDIT_CTR_HEX                1056
#define IDC_BUTTON_SINGCH               1057
#define IDC_EDIT_A2D_RESULT             1058
#define IDC_SPIN_CH_TEMP                1059
#define IDC_EDIT_DIGI_CH_TEMP           1060
#define IDC_BUTTON_TEMP_CONVERT         1061
#define IDC_BUTTON_TEMP_READ            1062
#define IDC_SPIN_A2D_CHANNEL            1063
#define IDC_EDIT_A2D_CHANNEL            1064
#define IDC_BUTTON_SENSOR_DETECT        1065
#define IDC_EDIT_TEMPSTATUS             1066
#define IDC_SPIN_TEMP_RES               1067
#define IDC_BUTTON_SET_RES              1068
#define IDC_EDIT_SENSOR_RES             1069
#define IDC_COMBO_CONVERSION_RESULT     1070
#define IDC_BUTTON_MULTIPLE             1072
#define IDC_SPIN_RATE                   1073
#define IDC_SPIN_NUMSAMPLES             1074
#define IDC_EDIT_RATE                   1075
#define IDC_EDIT_NUM_SAMPLES            1076
#define IDC_EDIT_ACQ_TIME               1077
#define IDC_BUTTON_STREAMON             1078
#define IDC_BUTTON_STREAMOFF            1079

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
