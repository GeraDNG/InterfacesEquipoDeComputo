// IO20Dlg.cpp : implementation file
#include "stdafx.h"
#include "IO20.h"
#include "IO20Dlg.h"
#include "ftd2xx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


char *BufPtrs[64]; // pointer to array of 64 pointers
DWORD numDevs;
unsigned char thread_rx[1100];

FT_HANDLE m_ftHandle;

CString Devstr;

int DigChannel, TempChannel, A2DChannel, DisplayRate;
int AcqTimeSamples;

double SamplePeriod;
int DisplayNumSamples;
int streammodeactive;
int gerror;


// CAboutDlg dialog used for App About
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIO20Dlg dialog

CIO20Dlg::CIO20Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIO20Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIO20Dlg)
	m_Status = _T("");
	m_PacketWindow = _T("");
	m_DigInput = 0;
	m_ChannelSel = _T("AN0");
	m_DigChannelCtr = 6;
	m_CtrRiseFall = 1;
	m_CtrHex = _T("");
	m_CtrDecimal = 0;
	m_ChannelSelTemp = _T("AN0");
	m_SensorResolution = 12;
	m_TempStatus = _T("");
	m_A2DChannel = _T("AN0");
	m_A2DResult = _T("");
	m_Rate = _T("1Ks/s");
	m_NumSamples = _T("128");
	m_AcqTime = _T("");
	m_StreamVoltage = _T("");
	m_RefSel = 0;
	m_RefVoltage = 3.3f;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CIO20Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIO20Dlg)
	DDX_Control(pDX, IDC_COMBO_CONVERSION_RESULT, m__ConversionResults);
	DDX_Control(pDX, IDC_COMBO1_DEVS, m_Devs);
	DDX_Text(pDX, IDC_EDIT_STATUS, m_Status);
	DDX_Text(pDX, IDC_EDIT_PACKET_WINDOW, m_PacketWindow);
	DDX_Text(pDX, IDC_EDIT_DIG_INPUT, m_DigInput);
	DDX_Text(pDX, IDC_EDIT_DIGI_CHANNEL, m_ChannelSel);
	DDX_Text(pDX, IDC_EDIT_DIGI_CHANNEL2, m_DigChannelCtr);
	DDX_Radio(pDX, IDC_RADIO_CTR_TRIGGER, m_CtrRiseFall);
	DDX_Text(pDX, IDC_EDIT_CTR_HEX, m_CtrHex);
	DDX_Text(pDX, IDC_EDIT_CTR_DECIMAL, m_CtrDecimal);
	DDX_Text(pDX, IDC_EDIT_DIGI_CH_TEMP, m_ChannelSelTemp);
	DDX_Text(pDX, IDC_EDIT_SENSOR_RES, m_SensorResolution);
	DDX_Text(pDX, IDC_EDIT_TEMPSTATUS, m_TempStatus);
	DDX_Text(pDX, IDC_EDIT_A2D_CHANNEL, m_A2DChannel);
	DDX_Text(pDX, IDC_EDIT_A2D_RESULT, m_A2DResult);
	DDX_Text(pDX, IDC_EDIT_RATE, m_Rate);
	DDX_Text(pDX, IDC_EDIT_NUM_SAMPLES, m_NumSamples);
	DDX_Text(pDX, IDC_EDIT_ACQ_TIME, m_AcqTime);
	DDX_Text(pDX, IDC_EDIT_STREAM_VOLTAGE, m_StreamVoltage);
	DDX_Radio(pDX, IDC_RADIO_REF_SELECT, m_RefSel);
	DDX_Text(pDX, IDC_EDIT_REF_VOLTAGE, m_RefVoltage);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIO20Dlg, CDialog)
	//{{AFX_MSG_MAP(CIO20Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, OnButtonConnect)
	ON_CBN_DROPDOWN(IDC_COMBO1_DEVS, OnDropdownCombo1)
	ON_BN_CLICKED(IDC_BUTTON_FLASH_LEDS, OnButtonFlashLeds)
	ON_BN_CLICKED(IDC_BUTTON_LED_ON, OnButtonLedOn)
	ON_BN_CLICKED(IDC_BUTTON_LED_OFF, OnButtonLedOff)
	ON_BN_CLICKED(IDC_BUTTON_R1_SET, OnButtonR1Set)
	ON_BN_CLICKED(IDC_BUTTON_R1_RESET, OnButtonR1Reset)
	ON_BN_CLICKED(IDC_BUTTON_R2_SET, OnButtonR2Set)
	ON_BN_CLICKED(IDC_BUTTON_R2_RESET, OnButtonR2Reset)
	ON_BN_CLICKED(IDC_BUTTON_DIG_HIGH, OnButtonDigHigh)
	ON_BN_CLICKED(IDC_BUTTON_DIG_READ, OnButtonDigRead)
	ON_BN_CLICKED(IDC_BUTTON_DIG_LOW, OnButtonDigLow)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN2, OnDeltaposSpin2)
	ON_BN_CLICKED(IDC_BUTTON_CTR_CLEAR, OnButtonCtrClear)
	ON_BN_CLICKED(IDC_BUTTON_CTR_READ, OnButtonCtrRead)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN3, OnDeltaposSpin3)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CH_TEMP, OnDeltaposSpinChTemp)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_TEMP_RES, OnDeltaposSpinTempRes)
	ON_BN_CLICKED(IDC_BUTTON_SET_RES, OnButtonSetRes)
	ON_BN_CLICKED(IDC_BUTTON_SENSOR_DETECT, OnButtonSensorDetect)
	ON_BN_CLICKED(IDC_BUTTON_TEMP_CONVERT, OnButtonTempConvert)
	ON_BN_CLICKED(IDC_BUTTON_TEMP_READ, OnButtonTempRead)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_A2D_CHANNEL, OnDeltaposSpinA2dChannel)
	ON_BN_CLICKED(IDC_BUTTON_SINGCH, OnButtonSingch)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_RATE, OnDeltaposSpinRate)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_NUMSAMPLES, OnDeltaposSpinNumsamples)
	ON_BN_CLICKED(IDC_BUTTON_MULTIPLE, OnButtonMultiple)
	ON_BN_CLICKED(IDC_BUTTON_STREAMON, OnButtonStreamon)
	ON_BN_CLICKED(IDC_BUTTON_STREAMOFF, OnButtonStreamoff)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_RADIO_REF_SELECT, OnRadioRefSelect)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIO20Dlg message handlers


void CIO20Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CIO20Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CIO20Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


//***************************************************************************
BOOL CIO20Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	DigChannel=0;
	SamplePeriod = .001;
	DisplayRate=0;
	A2DChannel=0;
	AcqTimeSamples = 128;




	return TRUE;  // return TRUE  unless you set the focus to a control
}



//***************************************************************************
void CIO20Dlg::OnDropdownCombo1() 
{
	FT_STATUS ftStatus;
	CString str;
	
	UpdateData(TRUE);
	//m_Location = _T("Closed");
	UpdateData(FALSE);
	UpdateWindow();

	m_Devs.ResetContent();
	FT_Close(m_ftHandle);
	UpdateData(TRUE);
	m_Status = _T(" ");
	UpdateData(FALSE);
	UpdateWindow();		

	//get number of attached devices
	ftStatus = FT_ListDevices(&numDevs, NULL, FT_LIST_NUMBER_ONLY);
	if(ftStatus == FT_OK) 
	{
		if(numDevs<=0)//error if no devices attached
		{
			str.Format("No devices attached");
			m_Devs.AddString(str);

			UpdateData(TRUE);
			m_Status = _T("No devices attached");
			UpdateData(FALSE);
			UpdateWindow();		
			return;
		}

		//allocate RAM for the number of devices connected
		for(DWORD d=0; d<=numDevs; d++)//create array of pointers
			BufPtrs[d] = new char[64];

		BufPtrs[d] = NULL;//null the first unused location


		//load array of pointers with description strings of attached devices
		ftStatus = FT_ListDevices(BufPtrs, &numDevs, FT_LIST_ALL|FT_OPEN_BY_DESCRIPTION);
		if (numDevs > 0) 
		{
			str.Format("%d device(s) attached:", (int)numDevs);
			m_Devs.AddString(str);
			
			for(DWORD u=0; u<numDevs; u++)
			{
				if(BufPtrs[u])
				{
					str.Format("%s", BufPtrs[u]);
					m_Devs.AddString(str);		
				}
			}
		}

		m_Devs.SetCurSel(1);//set the default

	}

	GetSelectedDevice();
}


//***************************************************************************
void CIO20Dlg::GetSelectedDevice(void)
{
	int t = m_Devs.GetCurSel();//get the selected index
	m_Devs.GetLBText(t, Devstr);
}





//***************************************************************************
void CIO20Dlg::OnButtonConnect() 
{
	FT_Close(m_ftHandle);
	int ret;

	ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port.");
		FT_Close(m_ftHandle);
		return;
	}

	FT_Close(m_ftHandle);

	UpdateData(TRUE);
	m_Status = _T("Port Ready");
	UpdateData(FALSE);
	UpdateWindow();
}




//*************************************************************************
int CIO20Dlg::OpenPort(void)
{
	int x=0;
	FT_STATUS status;
	CString str;
	unsigned char tx[400], rx[6000];
	DWORD AmountInRxQueue;
	DWORD ret_bytes;
	int pos;
	unsigned char Command = 0x27;//Ping


	GetSelectedDevice();

	status = FT_OpenEx((PVOID)(LPCTSTR)Devstr, FT_OPEN_BY_DESCRIPTION, &m_ftHandle);
	if(status)
	{		
		//AfxMessageBox("Error: Could not open a device (410)");
		return 1;
	}

	FT_SetTimeouts(m_ftHandle, 500, 500);

//	Sleep(50);
	Purge();

	//ping IO20 
	pos=0;
	tx[pos++] = 0x02;
	tx[pos++] = Command;
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		//AfxMessageBox("Error writing to DLP module. (514)");
		FT_Close(m_ftHandle);
		return 2;
	}

	int reply=100;//1000mS timeout
	while(reply>0)
	{
		reply--;
		Sleep(10);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue == 1)
			reply=0;
		
		if(reply==1)//timeout
			return 3;
	}

	status = FT_Read(m_ftHandle, rx, 1, &ret_bytes);
	if(status != FT_OK)
	{
		//AfxMessageBox("Read Error! (440)");
		FT_Close(m_ftHandle);
		return 4;
	}


	if(rx[0] != 'Y')
	{
		//AfxMessageBox("Error: Wrong data returned (460)");
		FT_Close(m_ftHandle);
		return 6;
	}
	

	return 0;
}


//****************************************************************************
FT_STATUS CIO20Dlg::SendPacket(unsigned char *tx, int pos)
{
	DWORD ret_bytes;
	FT_STATUS status;
	CString sss, yy;
	
	//put packet in edit box
	for (int x=0; x<pos; x++)
	{
		yy.Format("[%X]-", tx[x]);
		sss += yy;
	}
	
	sss += "\r\n";

	UpdateData(TRUE);
	m_PacketWindow.Insert(0, sss);
	UpdateData(FALSE);
	UpdateWindow();

	status = FT_Write(m_ftHandle, tx, pos, &ret_bytes);

	return status;
}

//****************************************************************************
void CIO20Dlg::OnButtonFlashLeds() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x28;//Flash LED

	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port.");
		FT_Close(m_ftHandle);
		return;
	}

	//flash LEDs
	pos=0;
	tx[pos++] = 0x02;
	tx[pos++] = Command; 
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (501)");
	}

	FT_Close(m_ftHandle);
}




//****************************************************************************
void CIO20Dlg::OnButtonLedOn() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x29;//LED Control

	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port.");
		FT_Close(m_ftHandle);
		return;
	}

	
	//LED on 
	pos=0;
	tx[pos++] = 0x03;
	tx[pos++] = Command; //Ping
	tx[pos++] = 0x00;//Port pin low - LED on
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
		AfxMessageBox("Error writing to DLP module. (502)");

	FT_Close(m_ftHandle);
}




//****************************************************************************
void CIO20Dlg::OnButtonLedOff() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x29;//LED Control


	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port.");
		FT_Close(m_ftHandle);
		return;
	}

	//LED off 
	pos=0;
	tx[pos++] = 0x03;
	tx[pos++] = Command; 
	tx[pos++] = 0x01;//Port pin high - LED off
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (503)");
	}

	FT_Close(m_ftHandle);
}



//****************************************************************************
void CIO20Dlg::OnButtonR1Set() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x30;//Relay Control

	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (570)");
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x04;
	tx[pos++] = Command; 
	tx[pos++] = 0x01;
	tx[pos++] = 0x00;
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (504)");
	}

	FT_Close(m_ftHandle);
}



//****************************************************************************
void CIO20Dlg::OnButtonR1Reset() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x30;//Relay Control

	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (600)");
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x04;
	tx[pos++] = Command; 
	tx[pos++] = 0x01;
	tx[pos++] = 0x01;
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (505)");
	}

	FT_Close(m_ftHandle);
}



//****************************************************************************
void CIO20Dlg::OnButtonR2Set() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x30;//Relay Control

	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (630)");
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x04;
	tx[pos++] = Command; 
	tx[pos++] = 0x02;
	tx[pos++] = 0x00;
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (506)");
	}

	FT_Close(m_ftHandle);
}



//****************************************************************************
void CIO20Dlg::OnButtonR2Reset() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x30;//Relay Control
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (660)");
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x04;
	tx[pos++] = Command; 
	tx[pos++] = 0x02;
	tx[pos++] = 0x01;
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (507)");
	}

	FT_Close(m_ftHandle);
}




//****************************************************************************
void CIO20Dlg::OnButtonDigHigh() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x35;//Digital I/O
	
	
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (1050)");
		FT_Close(m_ftHandle);
		return;
	}
		

	UpdateData(TRUE);

	pos=0;
	tx[pos++] = 5;
	tx[pos++] = Command; 
	tx[pos++] = DigChannel; 
	tx[pos++] = 0; //make this port an output 0=out, 1=in
	tx[pos++] = 1; //set it high (output mode)
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (508)");
	}

	FT_Close(m_ftHandle);
}


//****************************************************************************
void CIO20Dlg::OnButtonDigRead() 
{
	FT_STATUS status;
	unsigned char tx[40], rx[10];
	int pos;
	unsigned char Command = 0x35;//Digital I/O
	DWORD AmountInRxQueue, BytesReturned;
	
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (1080)");
		FT_Close(m_ftHandle);
		return;
	}

	Purge();
	UpdateData(TRUE);

	pos=0;
	tx[pos++] = 5;
	tx[pos++] = Command; 
	tx[pos++] = DigChannel; 
	tx[pos++] = 1; //make this port an input 0=out, 1=in
	tx[pos++] = 0; //don't care
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (509)");
	}

	FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	while(AmountInRxQueue==0)
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	if(AmountInRxQueue == 1)
		FT_Read(m_ftHandle, rx, 1, &BytesReturned);//read the data from the buffer
	else
	{
		AfxMessageBox("Error: Invalid data in buffer. (1120)");
		return;
	}

	m_DigInput = rx[0];
	UpdateData(FALSE);
	UpdateWindow();

	FT_Close(m_ftHandle);
}



//****************************************************************************
void CIO20Dlg::OnButtonDigLow() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x35;//Digital I/O
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (1080)");
		FT_Close(m_ftHandle);
		return;
	}
		

	UpdateData(TRUE);

	pos=0;
	tx[pos++] = 5;
	tx[pos++] = Command; 
	tx[pos++] = DigChannel; 
	tx[pos++] = 0; //make this port an output 0=out, 1=in
	tx[pos++] = 0; //set it low (output mode)
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (510)");
	}

	FT_Close(m_ftHandle);
}


//****************************************************************************
void CIO20Dlg::OnDeltaposSpin2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	UpdateData(TRUE); //read current data from the window
    
	DigChannel -= pNMUpDown->iDelta; //proposed change in position
	if(	DigChannel < 0)
		DigChannel = 0;
    if(DigChannel > 19)
		DigChannel = 19;

	switch (DigChannel)
	{
		case 0:	m_ChannelSel="AN0";	break;
		case 1:	m_ChannelSel="AN1";	break;
		case 2:	m_ChannelSel="AN2";	break;
		case 3:	m_ChannelSel="AN3";	break;
		case 4:	m_ChannelSel="AN4";	break;
		case 5:	m_ChannelSel="AN5";	break;
		case 6:	m_ChannelSel="AN6";	break;
		case 7:	m_ChannelSel="AN7";	break;
		case 8:	m_ChannelSel="AN8";	break;
		case 9:	m_ChannelSel="AN9";	break;
		case 10: m_ChannelSel="AN10"; break;
		case 11: m_ChannelSel="AN11"; break;
		case 12: m_ChannelSel="AN12"; break;
		case 13: m_ChannelSel="AN13"; break;
		case 14: m_ChannelSel="RA4"; break;
		case 15: m_ChannelSel="P5"; break;
		case 16: m_ChannelSel="P6"; break;
		case 17: m_ChannelSel="P7"; break;
		case 18: m_ChannelSel="RB7"; break;
		case 19: m_ChannelSel="RB6"; break;
		default: m_ChannelSel="AN0"; DigChannel=0;
	}
	UpdateData(FALSE);
	UpdateWindow();

	*pResult = 0;
}


//****************************************************************************
void CIO20Dlg::OnButtonCtrClear() //SETUP   SETUP
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x36;//Setup/Clear 32-bit Counter
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (1200)");
		FT_Close(m_ftHandle);
		return;
	}

	UpdateData(TRUE);

	pos=0;
	tx[pos++] = 4;
	tx[pos++] = Command; 
	tx[pos++] = m_DigChannelCtr; 
	tx[pos++] = m_CtrRiseFall;   //Rising/Falling
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (511)");
	}

	FT_Close(m_ftHandle);
}


//****************************************************************************
void CIO20Dlg::OnButtonCtrRead() 
{
	FT_STATUS status;
	unsigned char tx[40], rx[10];
	int pos;
	unsigned char Command = 0x37;//Read 32-bit Counter
	DWORD AmountInRxQueue, BytesReturned;
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (1230)");
		FT_Close(m_ftHandle);
		return;
	}

	UpdateData(TRUE);

	pos=0;
	tx[pos++] = 4;
	tx[pos++] = Command; 
	tx[pos++] = m_DigChannelCtr; 
	tx[pos++] = m_CtrRiseFall;   //Rising/Falling
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
	{
		AfxMessageBox("Error writing to DLP module. (512)");
	}
	
	FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	while(AmountInRxQueue==0)
	{
		Sleep(40);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	}
	if(AmountInRxQueue == 4)
		FT_Read(m_ftHandle, rx, 4, &BytesReturned);//read the data from the buffer
	else
	{
		AfxMessageBox("Error: Invalid data in buffer. (1250)");
		return;
	}

	int data = ( rx[0] | (rx[1]<<8) | (rx[2]<<16) | (rx[3]<<24)  );
	m_CtrHex.Format("0x%X", data);		
	m_CtrDecimal = data;		
	UpdateData(FALSE);
	UpdateWindow();
		
	FT_Close(m_ftHandle);	
}



//****************************************************************************
void CIO20Dlg::OnDeltaposSpin3(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	
	UpdateData(TRUE);
    
	m_DigChannelCtr -= pNMUpDown->iDelta; //proposed change in position
	if(	m_DigChannelCtr < 6)//6
		m_DigChannelCtr = 6;
    if(m_DigChannelCtr > 7)
		m_DigChannelCtr = 7;

	UpdateData(FALSE);
	UpdateWindow();	



	*pResult = 0;
}




//****************************************************************************
void CIO20Dlg::OnDeltaposSpinChTemp(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	

	UpdateData(TRUE); //read current data from the window
    
	TempChannel -= pNMUpDown->iDelta; //proposed change in position
	if(	TempChannel < 0)
		TempChannel = 0;
    if(TempChannel > 19)
		TempChannel = 19;
	
	//if((TempChannel > 14) && (TempChannel < 18))

	if(TempChannel == 15)
		TempChannel = 18;
	if(TempChannel == 17)
		TempChannel = 14;
	


	switch (TempChannel)
	{
		case 0:	m_ChannelSelTemp="AN0";	break;
		case 1:	m_ChannelSelTemp="AN1";	break;
		case 2:	m_ChannelSelTemp="AN2";	break;
		case 3:	m_ChannelSelTemp="AN3";	break;
		case 4:	m_ChannelSelTemp="AN4";	break;
		case 5:	m_ChannelSelTemp="AN5";	break;
		case 6:	m_ChannelSelTemp="AN6";	break;
		case 7:	m_ChannelSelTemp="AN7";	break;
		case 8:	m_ChannelSelTemp="AN8";	break;
		case 9:	m_ChannelSelTemp="AN9";	break;
		case 10: m_ChannelSelTemp="AN10"; break;
		case 11: m_ChannelSelTemp="AN11"; break;
		case 12: m_ChannelSelTemp="AN12"; break;
		case 13: m_ChannelSelTemp="AN13"; break;
		case 14: m_ChannelSelTemp="RA4"; break;
		//case 15: m_ChannelSelTemp="P5"; break;
		//case 16: m_ChannelSelTemp="P6"; break;
		//case 17: m_ChannelSelTemp="P7"; break;
		case 18: m_ChannelSelTemp="RB7"; break;//0x12
		case 19: m_ChannelSelTemp="RB6"; break;//0x13
		default: m_ChannelSelTemp="AN0"; DigChannel=0;
	}
	UpdateData(FALSE);
	UpdateWindow();
	
	*pResult = 0;
}


//****************************************************************************
void CIO20Dlg::OnDeltaposSpinTempRes(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	UpdateData(TRUE); //read current data from the window
    
	m_SensorResolution -= pNMUpDown->iDelta; //proposed change in position
	if(	m_SensorResolution < 9)
		m_SensorResolution = 9;
    if(m_SensorResolution > 12)
		m_SensorResolution = 12;

	UpdateData(FALSE);
	UpdateWindow();

	*pResult = 0;
}


//****************************************************************************
void CIO20Dlg::OnButtonSetRes() 
{
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x42;//Set Temperature Sensor Resolution
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (1270)");
		FT_Close(m_ftHandle);
		return;
	}

	UpdateData(TRUE);

	pos=0;
	tx[pos++] = 4;
	tx[pos++] = Command; 
	tx[pos++] = TempChannel; 
	tx[pos++] = m_SensorResolution; 
	SendPacket(tx, pos);
}


//****************************************************************************
void CIO20Dlg::Purge()
{
	DWORD AmountInRxQueue, BytesReturned;
	unsigned char rx[1001];

	Sleep(5);
	FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	if(AmountInRxQueue > 1000) AmountInRxQueue = 1000;
	while(AmountInRxQueue)
	{
		FT_Read(m_ftHandle, rx, AmountInRxQueue, &BytesReturned);//read the data from the buffer
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue > 1000) AmountInRxQueue = 1000;
		Sleep(5);
	}
}



//****************************************************************************
void CIO20Dlg::OnButtonSensorDetect() 
{
	unsigned char tx[40], rx[100000];
	int pos;
	DWORD AmountInRxQueue, BytesReturned;
	unsigned char Command = 0x39;//Temperature Sensor Detection
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (1290)");
		FT_Close(m_ftHandle);
		return;
	}

	UpdateData(TRUE);
	m_TempStatus.Format("--");		
	UpdateData(FALSE);
	UpdateWindow();

	Purge();

	pos=0;
	tx[pos++] = 3;
	tx[pos++] = Command; 
	tx[pos++] = TempChannel; 
	SendPacket(tx, pos);

	FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	while(AmountInRxQueue < 8)
	{
		Sleep(40);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	}
	if(AmountInRxQueue == 8)
		FT_Read(m_ftHandle, rx, 8, &BytesReturned);//read the data from the buffer
	else
	{
		AfxMessageBox("Error: Invalid data in buffer. (1300)");
		return;
	}

	int data1 = ( rx[0] | (rx[1]<<8) | (rx[2]<<16) | (rx[3]<<24)  );
	int data2 = ( rx[4] | (rx[5]<<8) | (rx[6]<<16) | (rx[7]<<24)  );

	if( (data1 < 10) && (data2 == 0))
	{
		m_TempStatus.Format("No sensor detected (Error:%d)", data1);		
	}
	else
	{
		m_TempStatus.Format("Ser #: 0x%X%X", data2, data1);		
	}

	UpdateData(FALSE);
	UpdateWindow();

	FT_Close(m_ftHandle);	
}


//****************************************************************************
void CIO20Dlg::OnButtonTempConvert() 
{
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x40;//Start Temperature Sensor Conversion
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (1320)");
		FT_Close(m_ftHandle);
		return;
	}

	UpdateData(TRUE);

	pos=0;
	tx[pos++] = 3;
	tx[pos++] = Command; 
	tx[pos++] = TempChannel; 
	SendPacket(tx, pos);	

	FT_Close(m_ftHandle);
}


//****************************************************************************
void CIO20Dlg::OnButtonTempRead() 
{
	unsigned char tx[40], rx[5];
	int pos;
	unsigned char Command = 0x41;//Read Temperature Sensor Data
	DWORD AmountInRxQueue, BytesReturned;
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (1340)");
		FT_Close(m_ftHandle);
		return;
	}


	UpdateData(TRUE);
	m_TempStatus.Format("--");		
	UpdateData(FALSE);
	UpdateWindow();

	Purge();

	pos=0;
	tx[pos++] = 3;
	tx[pos++] = Command; 
	tx[pos++] = TempChannel; 
	SendPacket(tx, pos);


	FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	while(AmountInRxQueue==0)
	{
		Sleep(40);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	}
	if(AmountInRxQueue == 2)
		FT_Read(m_ftHandle, rx, 2, &BytesReturned);//read the data from the buffer
	else
	{
		AfxMessageBox("Error: Invalid data in buffer. (1350)");
		FT_Close(m_ftHandle);		
		return;
	}

	if( (rx[0]==0) && (rx[1]==0) )
	{
		m_TempStatus.Format("still converting");		
		UpdateData(FALSE);
		UpdateWindow();
	}
	else
	{
		int isnegative=0;
		int temp = rx[0] | (rx[1] << 8);
		if( (temp & 0x8000) == 0x8000 )//if MSBit is set then negative temperature
		{
			temp &= 0x07ff;
			isnegative=1;
			temp = 0x800 - temp;
		}
		
		temp &= 0x07ff;	
		float degc1 = (float)((float)temp/16.0);
		if(isnegative) degc1 *= -1;

		m_TempStatus.Format("%02.2f�C     %02.2f�F ", degc1, degc1*9/5+32.0);		
		UpdateData(FALSE);
		UpdateWindow();
	}
	
	FT_Close(m_ftHandle);		
}


//************************************************************************
void CIO20Dlg::OnDeltaposSpinA2dChannel(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	
	UpdateData(TRUE); //read current data from the window
    
	A2DChannel -= pNMUpDown->iDelta; //proposed change in position
	if(	A2DChannel < 0)
		A2DChannel = 0;
    if(A2DChannel > 13)
		A2DChannel = 13;

	switch (A2DChannel)
	{
		case 0:	m_A2DChannel="AN0";	break;
		case 1:	m_A2DChannel="AN1";	break;
		case 2:	m_A2DChannel="AN2";	break;
		case 3:	m_A2DChannel="AN3";	break;
		case 4:	m_A2DChannel="AN4";	break;
		case 5:	m_A2DChannel="AN5";	break;
		case 6:	m_A2DChannel="AN6";	break;
		case 7:	m_A2DChannel="AN7";	break;
		case 8:	m_A2DChannel="AN8";	break;
		case 9:	m_A2DChannel="AN9";	break;
		case 10: m_A2DChannel="AN10"; break;
		case 11: m_A2DChannel="AN11"; break;
		case 12: m_A2DChannel="AN12"; break;
		case 13: m_A2DChannel="AN13"; break;
		default: m_A2DChannel="AN0"; DigChannel=0;
	}
	UpdateData(FALSE);
	UpdateWindow();

	*pResult = 0;
}


//***************************************************************************
void CIO20Dlg::OnButtonSingch() 
{
	unsigned char tx[40], rx[5];
	int pos;
	unsigned char Command = 0x50;//Read Single channel, single A/D conversion
	DWORD AmountInRxQueue, BytesReturned;
	float volts;
	
	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (120)");
		FT_Close(m_ftHandle);
		return;
	}


	UpdateData(TRUE);
	m_A2DResult.Format("--");		
	UpdateData(FALSE);
	UpdateWindow();

	Purge();

	pos=0;
	tx[pos++] = 3;
	tx[pos++] = Command; 
	tx[pos++] = A2DChannel; 
	SendPacket(tx, pos);

//does not select a channel!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


	FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	while(AmountInRxQueue==0)
	{
		Sleep(40);
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	}
	if(AmountInRxQueue == 2)
		FT_Read(m_ftHandle, rx, 2, &BytesReturned);//read the data from the buffer
	else
	{
		AfxMessageBox("Error: Invalid data in buffer. (130)");
		FT_Close(m_ftHandle);		
		return;
	}

	//determine the selected reference voltage
	float refvoltage;
	if(m_RefSel==0)
	{
		refvoltage=5.0;
	}
	else
	{
		UpdateData(TRUE);		
		refvoltage = m_RefVoltage;
	}


	int temp = rx[0] | (rx[1] << 8);

	volts = (float)((float)temp*refvoltage/1023.0);

	m_A2DResult.Format("%02.3fV", volts);		
	UpdateData(FALSE);
	UpdateWindow();
	
	FT_Close(m_ftHandle);			

}




//***************************************************************************
void CIO20Dlg::OnDeltaposSpinRate(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	UpdateData(TRUE); //read current data from the window
    
	DisplayRate -= pNMUpDown->iDelta; //proposed change in position
	if(	DisplayRate < 0)
		DisplayRate = 0;
    if(DisplayRate > 4)
		DisplayRate = 4;

	switch (DisplayRate)
	{
	case 0:
		m_Rate = _T("1Ks/s");
		SamplePeriod = .001;
		break;
	case 1:
		m_Rate = _T("2Ks/s");
		SamplePeriod = .0005;
		break;
	case 2:
		m_Rate = _T("4Ks/s");
		SamplePeriod = .00025;
		break;
	case 3:
		m_Rate = _T("10Ks/s");
		SamplePeriod = .0001;
		break;
	case 4:
		m_Rate = _T("20Ks/s");
		SamplePeriod = .00005;
		break;
	}
	
	UpdateData(FALSE);
	UpdateWindow();


	*pResult = 0;
}





//***************************************************************************
void CIO20Dlg::OnDeltaposSpinNumsamples(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;


	UpdateData(TRUE); //read current data from the window
    
	DisplayNumSamples -= pNMUpDown->iDelta; //proposed change in position

	if(	DisplayNumSamples < 0)
		DisplayNumSamples = 0;
    if(DisplayNumSamples > 6)
		DisplayNumSamples = 6;


	switch (DisplayNumSamples)
	{
	case 0:
		m_NumSamples = _T("128");
		AcqTimeSamples = 128;
		break;
	case 1:
		m_NumSamples = _T("256");
		AcqTimeSamples = 256;
		break;
	case 2:
		m_NumSamples = _T("512");
		AcqTimeSamples = 512;
		break;
	case 3:
		m_NumSamples = _T("1024");
		AcqTimeSamples = 1024;
		break;
	case 4:
		m_NumSamples = _T("2048");
		AcqTimeSamples = 2048;
		break;
	case 5:
		m_NumSamples = _T("4096");
		AcqTimeSamples = 4096;
		break;
	case 6:
		m_NumSamples = _T("8192");
		AcqTimeSamples = 8192;
		break;
	}

	UpdateData(FALSE);
	UpdateWindow();
	

	*pResult = 0;
}




//***************************************************************************
void CIO20Dlg::OnButtonMultiple() 
{
	unsigned char tx[10], rx[5];
	double volts;
	CString str;
	int pos, temp;
	int count;
	int done;
	unsigned char Command = 0x51;//Read Multiple A/D conversions
	DWORD AmountInRxQueue, BytesReturned;


	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (150)");
		FT_Close(m_ftHandle);
		return;
	}


	UpdateData(TRUE);
	m_A2DResult.Format("--");		
	m__ConversionResults.ResetContent();	
	double acqtime;
	acqtime = SamplePeriod * AcqTimeSamples;
	m_AcqTime.Format("%02.5f Sec", (float)acqtime);
	UpdateData(FALSE);
	UpdateWindow();


	Purge();

	pos=0;
	tx[pos++] = 5;
	tx[pos++] = Command; 
	tx[pos++] = A2DChannel; 
	tx[pos++] = DisplayRate; 
	tx[pos++] = DisplayNumSamples; 
	int status = SendPacket(tx, pos);
	if(status != FT_OK)
	{
		AfxMessageBox("Error: Unable to write to target. (160)");
		FT_Close(m_ftHandle);		
		return;
	}

	//determine the selected reference voltage
	float refvoltage;
	if(m_RefSel==0)
	{
		refvoltage=5.0;
	}
	else
	{
		UpdateData(TRUE);		
		refvoltage = m_RefVoltage;
	}

	//start returning data bytes, calculate voltage in real time.
	count=0;
	done=0;
	while(done==0)
	{
		//message pump
		MSG message;
		if(::PeekMessage(&message, NULL, 0, 0, PM_REMOVE)) 
		{
			::TranslateMessage(&message);
			::DispatchMessage(&message);
		}

		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue  > 1)
		{
			FT_Read(m_ftHandle, rx, 2, &BytesReturned);//read the data from the buffer
			
			temp = ( (rx[1] << 8) | rx[0] );
			volts = (float)((float)temp*refvoltage/1023.0);			
			str.Format("%02.3fV", volts);		
			m__ConversionResults.InsertString(count, str);
		
			count++;
			if(count>=AcqTimeSamples)
				done=1;		
		}
	}
	
	m__ConversionResults.InsertString(0, "Acq complete");
	m__ConversionResults.SetCurSel(0);
	UpdateWindow();
	
	FT_Close(m_ftHandle);
}



//***************************************************************************
void CIO20Dlg::OnButtonStreamon() 
{
	unsigned char tx[10], rx[20000];
	CString str;
	int pos;
	unsigned char Command = 0x52;//stream on
	DWORD AmountInRxQueue, BytesReturned;


	OnButtonLedOff(); 

	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port. (150)");
		FT_Close(m_ftHandle);
		return;
	}

	UpdateData(TRUE);
	m_A2DResult.Format(" ");		
	m__ConversionResults.ResetContent();	
	m_AcqTime.Format(" ");
	UpdateData(FALSE);
	UpdateWindow();

	//PURGE
	Sleep(5);
	FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
	if(AmountInRxQueue > 1000) AmountInRxQueue = 1000;
	while(AmountInRxQueue)
	{
		FT_Read(m_ftHandle, rx, AmountInRxQueue, &BytesReturned);//read the data from the buffer
		FT_GetQueueStatus(m_ftHandle, &AmountInRxQueue);//check buffer for returned data
		if(AmountInRxQueue > 1000) AmountInRxQueue = 1000;
		Sleep(5);
	}

	//Send command to begin streaming
	pos=0;
	tx[pos++] = 4;
	tx[pos++] = Command; 
	tx[pos++] = A2DChannel; 
	tx[pos++] = DisplayRate; 
	//tx[pos++] = 99; //number of samples
	int status = SendPacket(tx, pos);
	if(status != FT_OK)
	{
		AfxMessageBox("Error: Unable to write to target. (160)");
		FT_Close(m_ftHandle);		
		return;
	}

	streammodeactive=1;
	AfxBeginThread(ThreadProc, this, THREAD_PRIORITY_NORMAL);
	SetTimer(100, 50, NULL);
}

//*****************************************************************
void CIO20Dlg::OnTimer(UINT nIDEvent) 
{
	double volts;
	CString str;
	int temp;
	unsigned char Command = 0x52;//stream on

	if(gerror > 0)
	{
		KillTimer(100);
		streammodeactive=0;
		Sleep(50);
		Purge();
		FT_Close(m_ftHandle);
		OnButtonLedOn(); 
		AfxMessageBox("Error: excessive data collected in buffer");
		return;		
	}

	//determine the selected reference voltage
	float refvoltage;
	if(m_RefSel==0)
	{
		refvoltage=5.0;
	}
	else
	{
		UpdateData(TRUE);		
		refvoltage = m_RefVoltage;
	}


	temp = ( (thread_rx[1] << 8) | thread_rx[0] );
	volts = (float)((float)temp*refvoltage/1023.0);			

	UpdateData(TRUE);
	m_StreamVoltage.Format("%02.3fV", volts);		
	UpdateData(FALSE);
	UpdateWindow();

	CDialog::OnTimer(nIDEvent);
}

//****************************************************************************
UINT ThreadProc(LPVOID param)
{
	DWORD ret_bytes;
	DWORD bytes_in_buf;

	//typecast the handle to the parent window
	CIO20Dlg *pMyHndl = (CIO20Dlg *)param;

	gerror=0;//init global error flag to no error
	while(streammodeactive==1)
	{
		FT_GetQueueStatus(m_ftHandle, &bytes_in_buf);
		if(bytes_in_buf>5000)
			gerror=1;
		if(bytes_in_buf>500)
			FT_Read(m_ftHandle, thread_rx, 1000, &ret_bytes);
    }

	return 0;
}

//*****************************************************************
void CIO20Dlg::OnButtonStreamoff() 
{
	unsigned char tx[10];
	unsigned char Command = 0x29;//LED Control
	FT_STATUS status;

	//kill timer in IO20	
	//LED on 
	int pos=0;
	tx[pos++] = 0x03;
	tx[pos++] = Command; //Ping
	tx[pos++] = 0x00;//Port pin low - LED on
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
		AfxMessageBox("Error writing to DLP module. (502)");

	KillTimer(100);//kill timer in GUI
	streammodeactive=0;
	Sleep(1000);//wait for all data to arrive at host
	Purge();
	FT_Close(m_ftHandle);

}



/*		//message pump
		MSG message;
		if(::PeekMessage(&message, NULL, 0, 0, PM_REMOVE)) 
		{
			::TranslateMessage(&message);
			::DispatchMessage(&message);
		}
*/







//****************************************************************************
void CIO20Dlg::OnRadioRefSelect() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x54;//5V USB reference select



	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port.");
		FT_Close(m_ftHandle);
		return;
	}

	pos=0;
	tx[pos++] = 0x02;
	tx[pos++] = Command; 
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
		AfxMessageBox("Error writing to DLP module. (522)");

	FT_Close(m_ftHandle);	

	CEdit *pEdt_gen;
	pEdt_gen = (CEdit *)GetDlgItem(IDC_EDIT_REF_VOLTAGE);
	pEdt_gen->SetReadOnly(TRUE);
}




//****************************************************************************
void CIO20Dlg::OnRadio3() 
{
	FT_STATUS status;
	unsigned char tx[40];
	int pos;
	unsigned char Command = 0x53;//external AN3 reference select

	FT_Close(m_ftHandle);
	int ret = OpenPort();//returns 0 for success
	if(ret>0)
	{
		AfxMessageBox("Error: Could not open the port.");
		FT_Close(m_ftHandle);
		return;
	}


	AfxMessageBox("You have selected to use an externally connected\n \
reference.  You must connect your refernce voltage\n\
to terminal AN3 and enter that voltage value\n\
into the edit box on the GUI in order for the GUI\n\
to be able to correctly calculate the measured\n\
voltage.  Note that the refence voltage must be in\n\
the range of 2.7 to 5.0 volts and only numeric\n\
characters can be entered.");


	pos=0;
	tx[pos++] = 0x02;
	tx[pos++] = Command; 
	status = SendPacket(tx, pos);
	if(status != FT_OK) 
		AfxMessageBox("Error writing to DLP module. (513)");

	FT_Close(m_ftHandle);	
	
	CEdit *pEdt_gen;
	pEdt_gen = (CEdit *)GetDlgItem(IDC_EDIT_REF_VOLTAGE);
	pEdt_gen->SetReadOnly(FALSE);
}
