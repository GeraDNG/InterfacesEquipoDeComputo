// IO20Dlg.h : header file
#include "ftd2xx.h"


#if !defined(AFX_IO20DLG_H__A995D67C_F278_486C_B8A7_45A3A85881BE__INCLUDED_)
#define AFX_IO20DLG_H__A995D67C_F278_486C_B8A7_45A3A85881BE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000




UINT ThreadProc(LPVOID param);




// CIO20Dlg dialog
class CIO20Dlg : public CDialog
{
// Construction
public:
	CIO20Dlg(CWnd* pParent = NULL);	// standard constructor
	void CIO20Dlg::GetSelectedDevice(void);
	int CIO20Dlg::OpenPort(void);
	FT_STATUS CIO20Dlg::SendPacket(unsigned char *tx, int pos);
	void CIO20Dlg::Purge();




// Dialog Data
	//{{AFX_DATA(CIO20Dlg)
	enum { IDD = IDD_IO20_DIALOG };
	CComboBox	m__ConversionResults;
	CComboBox	m_Devs;
	CString	m_Status;
	CString	m_PacketWindow;
	int		m_DigInput;
	CString	m_ChannelSel;
	int		m_DigChannelCtr;
	int		m_CtrRiseFall;
	CString	m_CtrHex;
	int		m_CtrDecimal;
	CString	m_ChannelSelTemp;
	int		m_SensorResolution;
	CString	m_TempStatus;
	CString	m_A2DChannel;
	CString	m_A2DResult;
	CString	m_Rate;
	CString	m_NumSamples;
	CString	m_AcqTime;
	CString	m_StreamVoltage;
	int		m_RefSel;
	float	m_RefVoltage;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIO20Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CIO20Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonConnect();
	afx_msg void OnDropdownCombo1();
	afx_msg void OnButtonFlashLeds();
	afx_msg void OnButtonLedOn();
	afx_msg void OnButtonLedOff();
	afx_msg void OnButtonR1Set();
	afx_msg void OnButtonR1Reset();
	afx_msg void OnButtonR2Set();
	afx_msg void OnButtonR2Reset();
	afx_msg void OnButtonDigHigh();
	afx_msg void OnButtonDigRead();
	afx_msg void OnButtonDigLow();
	afx_msg void OnDeltaposSpin2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonCtrClear();
	afx_msg void OnButtonCtrRead();
	afx_msg void OnDeltaposSpin3(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinChTemp(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinTempRes(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonSetRes();
	afx_msg void OnButtonSensorDetect();
	afx_msg void OnButtonTempConvert();
	afx_msg void OnButtonTempRead();
	afx_msg void OnDeltaposSpinA2dChannel(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonSingch();
	afx_msg void OnDeltaposSpinRate(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinNumsamples(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonMultiple();
	afx_msg void OnButtonStreamon();
	afx_msg void OnButtonStreamoff();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRadioRefSelect();
	afx_msg void OnRadio3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IO20DLG_H__A995D67C_F278_486C_B8A7_45A3A85881BE__INCLUDED_)
