//==============================================================================
//
// Title:       Terminal
// Purpose:     Using the DLPDesign IO20 to read temperatures from Port 2
//
// Created on:  13/04/2010 at 04:13:08 p.m. by Rick Swenson.
// Copyright:   ITESM. All Rights Reserved.
//
// Instructions:
//    1) Obtain a LM35 temperature sensor
//    2) Connect the LM35 voltage input  to the +5V terminal of the IO-20
//    3) Connect the LM35 ground  input  to the Gnd terminal of the IO-20
//    4) Connect the LM35 central output to the 2   terminal of the IO-20
//==============================================================================

//==============================================================================
// Include files

#include <rs232.h>
#include <ansi_c.h>
#include <cvirte.h>     
#include <userint.h>
#include "Terminal.h"
#include "toolbox.h"

//==============================================================================
// Constants
#define  comport          2  
#define  baudrate         115200
#define  databits         8
#define  stopbits         1
#define  inputbuffersize  2       // Number of characters that will be received
#define  outputbuffersize 1       // Number of characters that will be transmitted


//==============================================================================
// Types

//==============================================================================
// Static global variables

static int panelHandle;

//==============================================================================
// Static functions

//==============================================================================
// Global variables
  char LED = 0;

//==============================================================================
// Global functions

/// HIFN The main entry-point function.
int main (int argc, char *argv[])
{
    int error = 0;
    
    /* initialize and load resources */
    nullChk (InitCVIRTE (0, argv, 0));
    errChk (panelHandle = LoadPanel (0, "Terminal.uir", PANEL));
	
    /* display the panel and run the user interface */
    errChk (DisplayPanel (panelHandle));
    errChk (RunUserInterface ());

Error:
    /* clean up */
    DiscardPanel (panelHandle);
    return 0;
}

//==============================================================================
// UI callback function prototypes

/// HIFN Exit when the user dismisses the panel.
int CVICALLBACK panelCB (int panel, int event, void *callbackData,
        int eventData1, int eventData2)
{
    if (event == EVENT_CLOSE)
        QuitUserInterface (0);
    return 0;
}

int CVICALLBACK SendCB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	unsigned char number1, number2, number3 = 0;
	unsigned char receive[inputbuffersize+1]; 


	switch (event)
	{
		case EVENT_COMMIT:
	        /* Open serial port */
			
			OpenComConfig (comport, "", baudrate, 0, databits, stopbits, inputbuffersize, outputbuffersize);
			 
			GetCtrlVal (panelHandle, PANEL_NUMERIC1, &number1);
			ComWrtByte (comport,number1);
			GetCtrlVal (panelHandle, PANEL_NUMERIC2, &number2);
			ComWrtByte (comport,number2);
			GetCtrlVal (panelHandle, PANEL_NUMERIC3, &number3);
			ComWrtByte (comport,number3);
			//Flash LED to indicate character was transmitted
			LED = 1;
			SetCtrlVal (panelHandle, PANEL_LED, LED);
			Delay(0.4); // Wait for a short period of time
			LED = 0;
			SetCtrlVal (panelHandle, PANEL_LED, LED);
			
			ComRd(comport,receive,inputbuffersize);
			// Add a null character at the end of the received string.
			receive[inputbuffersize]='\0';
				
			SetCtrlVal(panelHandle,PANEL_NUMERIC_2, receive);
			
			
		    //Close serial port
		    CloseCom (comport);
			break;
	}
	return 0;
}
