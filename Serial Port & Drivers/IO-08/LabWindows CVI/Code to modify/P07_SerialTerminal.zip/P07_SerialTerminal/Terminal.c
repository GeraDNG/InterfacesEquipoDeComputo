//==============================================================================
//
// Title:       Terminal
// Purpose:     A short description of the application.
//
// Created on:  13/04/2010 at 04:13:08 p.m. by Rick Swenson.
// Copyright:   ITESM. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <rs232.h>
#include <ansi_c.h>
#include <cvirte.h>     
#include <userint.h>
#include "Terminal.h"
#include "toolbox.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

static int panelHandle;

//==============================================================================
// Static functions

//==============================================================================
// Global variables
  char LED = 0;

//==============================================================================
// Global functions

/// HIFN The main entry-point function.
int main (int argc, char *argv[])
{
    int error = 0;
    
    /* initialize and load resources */
    nullChk (InitCVIRTE (0, argv, 0));
    errChk (panelHandle = LoadPanel (0, "Terminal.uir", PANEL));
	
    /* display the panel and run the user interface */
    errChk (DisplayPanel (panelHandle));
    errChk (RunUserInterface ());

Error:
    /* clean up */
    DiscardPanel (panelHandle);
    return 0;
}

//==============================================================================
// UI callback function prototypes

/// HIFN Exit when the user dismisses the panel.
int CVICALLBACK panelCB (int panel, int event, void *callbackData,
        int eventData1, int eventData2)
{
    if (event == EVENT_CLOSE)
        QuitUserInterface (0);
    return 0;
}

int CVICALLBACK SendCB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	unsigned char car[10];

	switch (event)
	{
		case EVENT_COMMIT:
	        /* Open serial port */
			
			OpenComConfig (14, "", 115200, 0, 8, 1, 10, 10);
			
			GetCtrlVal (panelHandle, PANEL_CHARACTER, car);
			ComWrtByte (14, car[0]);
			//ComWrt (14, car, 1);
			
			//Toggle LED
			LED = ~LED;
			SetCtrlVal (panelHandle, PANEL_LED, LED);
			
		    //Close serial port
		    CloseCom (14);
			break;
	}
	return 0;
}
